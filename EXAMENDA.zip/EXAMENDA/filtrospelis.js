const countries = [
    "USA",
    "UK",
    "Canada",
    "Spain",
    "France",
    "Germany",
    "Hong Kong",
    "Ireland",
];
const genders = [
    "Horror",
    "Action",
    "Fantasy",
    "Drama",
    "Sci-Fi",
    "Biography",
    "Comedy",
    "Adventure",
    "Thriller",
    "History"
];