const tareas = [
    { Titulo: "Deberes", FechaVen: "2026-05-14", Prioridad: "baja", Completado: false, Creacion: new Date() },
    { Titulo: "Limpiar", FechaVen: "2027-05-14", Prioridad: "alta", Completado: false, Creacion: new Date() },
    { Titulo: "Ordenar", FechaVen: "2028-05-14", Prioridad: "media", Completado: false, Creacion: new Date() },
]